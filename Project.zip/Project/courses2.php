<?php
session_start();
$login = false;
$showLoginAlert = false;
$showLoginButton = true;


if($_SERVER['REQUEST_METHOD']=="POST"){
  include 'dbconnect.php';
  $login_email = $_POST["login_email"];
  $login_password = $_POST["login_password"];

  $query2 = "SELECT * FROM users_all WHERE email = '$login_email' AND password = '$login_password';";
  $query3 = "SELECT username FROM users_all WHERE email = '$login_email';";
  
  $result1 = mysqli_query($conn, $query2);
  $result2 = mysqli_query($conn, $query3);

  
  $username = mysqli_fetch_assoc($result2);

  $usernum = mysqli_num_rows($result1);


  if($usernum == 1){
    $login = true;
    $_SESSION['loggedin'] = true;
    $_SESSION['email'] = $login_email;
    $_SESSION['username'] = $username;
    header("location: index.php");
  }else{
    $showLoginAlert = true;
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <style>
      *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }
      .container{
        margin: 0 auto 0 auto;
        width: 80%;
      }
    </style>
</head>
<body style="background-image: url(background1.1.png); background-size: contain;">

<nav class="navbar navbar-expand-lg" data-bs-theme="dark" style="background-color: #030303;">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
            <img src="elements/logo.png" alt="Logo" width="28" height="28" class="d-inline-block align-text-top">
            OLPA
          </a>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="courses.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="pricing.php">Membership</a>
              </li>
            </ul>
          </div>

          <?php if(isset($_SESSION['loggedin'])){ ?>

            <a href="profile.php"><button type="button" class="btn btn-outline-light">Your Profile</button></a>

          <?php }else{
          echo '

          <!-- LOGIN MODAL-->
          <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Login
          </button>
          
          <div class="modal" style="color: white;" tabindex="-1" id="exampleModal">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Enter your email and password</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="index.php">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="email" name="login_email" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="login_password">
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;">Login</button>
                    <div style="text-align: center; margin-top: 20px;">
                        <a href="">Forgot Password?</a>
                    </div>
                </form>
                </div>
                <hr style="margin-top: 0px;">
                <div>
                  <div class="form-text"  style="text-align: center; margin-top: 0; margin-bottom: 15px;">Do not have an account? <br><a href="signup.php  ">Sign Up</a> Here.</div>
                </div>
              </div>
            </div>
          </div>';
          }
          ?>
        </div>
      </nav>
      <?php
          if($showLoginAlert){
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Error!</strong> Your password or username is incorrect.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
          }
          if($login){
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> You are logged in.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
          }
          ?>

      
      
      <div class="container mt-5 mb-5">
        <h2>Here are the courses available</h2>

        <p>Courses to get you started with coding</p><br>
        <div class="row row-cols-1 row-cols-md-4 g-4">
        <div class="col">
        <div class="card" style="width: 16rem;">
          <img src="elements/react.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">React Development</h5>
            <p class="card-text" style="margin-top: -10px;"><small class="text-body-secondary">Author: Zephyr Forge </small></p>
            <p class="card-text" style="font-weight: 400; font-size: 20px; margin-top: -10px;">$60.00</p>
            <a href="java.php" class="btn btn-primary">Get Started</a>
          </div>
        </div>
        </div>
        <div class="col">
          <div class="card" style="width: 16rem;">
            <img src="elements/ml.png" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Machine Learning</h5>
              <p class="card-text" style="margin-top: -10px;"><small class="text-body-secondary">Author: Isla Rodriguez </small></p>
              <p class="card-text" style="font-weight: 400; font-size: 20px; margin-top: -10px;">$59.99</p>
              <a href="php.php" class="btn btn-primary">Get Started</a>
            </div>
          </div>
          </div>
          <div class="col">
            <div class="card" style="width: 16rem;">
              <img src="elements/bootstrap.png" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Bootstrap Development</h5>
                <p class="card-text" style="margin-top: -10px;"><small class="text-body-secondary">Author: Finnegan Lee </small></p>
                <p class="card-text" style="font-weight: 400; font-size: 20px; margin-top: -10px;">$30.99</p>
                <a href="js.php" class="btn btn-primary">Get Started</a>
              </div>
            </div>
            </div>
            <div class="col">
              <div class="card" style="width: 16rem;">
                <img src="elements/css.png" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">CSS Designing</h5>
                  <p class="card-text" style="margin-top: -10px;"><small class="text-body-secondary">Author: Scarlett Martinez </small></p>
                  <p class="card-text" style="font-weight: 400; font-size: 20px; margin-top: -10px;">$35.99</p>
                  <a href="css.php" class="btn btn-primary">Get Started</a>
                </div>
              </div>
              </div>
              <div class="col">
                <div class="card" style="width: 16rem;">
                  <img src="elements/c.png" class="card-img-top" alt="...">
                  <div class="card-body">
                    <h5 class="card-title">C Programming</h5>
                    <p class="card-text" style="margin-top: -10px;"><small class="text-body-secondary">Author: Luna Brooks</small></p>
                    <p class="card-text" style="font-weight: 400; font-size: 20px; margin-top: -10px;">$40.00</p>
                    <a href="C.php" class="btn btn-primary">Get Started</a>
                  </div>
                </div>
                </div>
                <div class="col">
                  <div class="card" style="width: 16rem;">
                    <img src="elements/c++.png" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h5 class="card-title">C++ Programming</h5>
                      <p class="card-text" style="margin-top: -10px;"><small class="text-body-secondary">Author: Asher Thompson</small></p>
                      <p class="card-text" style="font-weight: 400; font-size: 20px; margin-top: -10px;">$19.99</p>
                      <a href="C++.php" class="btn btn-primary">Get Started</a>
                    </div>
                  </div>
                  </div>
                  <div class="col">
                    <div class="card" style="width: 16rem;">
                      <img src="elements/SQL.png" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">SQL Database</h5>
                        <p class="card-text" style="margin-top: -10px;"><small class="text-body-secondary">Author: Harper Patel</small></p>
                        <p class="card-text" style="font-weight: 400; font-size: 20px; margin-top: -10px;">$25.99</p>
                        <a href="SQL.php" class="btn btn-primary">Get Started</a>
                      </div>
                    </div>
                    </div>
                    <div class="col">
                      <div class="card" style="width: 16rem;">
                        <img src="elements/python.png" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Python Programming</h5>
                          <p class="card-text" style="margin-top: -10px;"><small class="text-body-secondary">Author: Declan Nguyen</small></p>
                          <p class="card-text" style="font-weight: 400; font-size: 20px; margin-top: -10px;">$50.00</p>
                          <a href="python.php" class="btn btn-primary">Get Started</a>
                        </div>
                      </div>
                      </div>
        </div>
      </div>
      </div>
      <div style="margin-left: 250px;"> 
      <nav aria-label="Page navigation example">
  <ul class="pagination">
    <li class="page-item"><a class="page-link" href="courses.php">Previous</a></li>
    <li class="page-item"><a class="page-link" href="courses2.php">1</a></li>
    <li class="page-item"><a class="page-link" href="courses3.php">2</a></li>
    <li class="page-item"><a class="page-link" href="courses4.php">3</a></li>
    <li class="page-item"><a class="page-link" href="courses3.php">Next</a></li>
  </ul>
</nav>
      



      <script src="js/bootstrap.js"></script>
</body>
</html>