<?php
include 'dbconnect.php'; // Include database connection script
$showAlert = false;
$showError = false;
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
    header("location: loginpage.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $bankName = $_POST['bankName'];
    $cardNum = $_POST['cardnum'];
    $coursename = $_POST['course'];
    $courseprice = 0;
    $userID = $_SESSION['id'];

    // Set course prices based on selected courses
    if ($coursename == "Java Programming") {
        $courseprice = 50.00;
    } elseif ($coursename == "PHP Programming") {
        $courseprice = 39.99;
    } elseif ($coursename == "JavaScript for Beginners") {
        $courseprice = 45.99;
    } elseif ($coursename == "CSS Designing") {
        $courseprice = 35.99;
    } elseif ($coursename == "C Programming") {
        $courseprice = 40.00;
    } elseif ($coursename == "C++ Programming") {
        $courseprice = 19.99;
    } elseif ($coursename == "SQL Database") {
        $courseprice = 25.99;
    } elseif ($coursename == "Python Programming") {
        $courseprice = 50.00;
    } else {
        // Default price if no course is selected or if it's an unrecognized course
        $courseprice = 0;
    }

    $query1 = "INSERT INTO `coursesenrolled` (`courseName`, `price`, `id`) VALUES ('$coursename', '$courseprice', '$userID');";
    $queryw = "INSERT INTO `carddetails` ( `bankname`, `cardnum`, `id`) VALUES ('$bankName', '$cardNum', '$userID');";

    $result1 = mysqli_query($conn, $query1);
    $result2 = mysqli_query($conn, $queryw);

    if ($result1 && $result2) {
        $showAlert = true;
    } else {
        $showError = true;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.css">
    <title>Checkout</title>
</head>
<body style="background-image: url(background1.1.png); background-size: cover;"> 
<nav class="navbar navbar-expand-lg" data-bs-theme="dark" style="background-color: #030303;">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
            <img src="elements/logo.png" alt="Logo" width="28" height="28" class="d-inline-block align-text-top">
            OLPA
          </a>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="courses.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="pricing.php">Membership</a>
              </li>
            </ul>
          </div>

          <?php if(isset($_SESSION['loggedin'])){ ?>

            <a href="profile.php"><button type="button" class="btn btn-outline-light">Your Profile</button></a>

          <?php }
          ?>
        </div>
      </nav>
<?php 
if($showAlert){
    echo '
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <strong>Success!</strong> Your course has been added to your account.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
    }
    if($showError){
        echo '
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <strong>Error!</strong> Some Error occured while adding your entry. Please try again after some time.
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
        } ?>

      <div style="width: 50%; margin: 100px auto 0 auto; border: solid grey 1px; padding: 10px; border-radius: 10px;">
      <h2>Please confirm your purchase.</h2>
      <form action="coursepurchase.php" method="POST">
      <div class="mb-3 row">
            <label for="staticEmail" class="col-sm-2 col-form-label">Your Username</label>
            <div class="col-sm-10">
                <input type="text" readonly class="form-control-plaintext" id="staticEmail" value="<?php echo $_SESSION['username']['username']; ?>">
            </div>
        </div>
      <div class="mb-3 row">
            <label for="staticEmail" class="col-sm-2 col-form-label"> Your Email</label>
            <div class="col-sm-10">
                <input type="text" readonly class="form-control-plaintext" id="staticEmail" value="<?php echo $_SESSION['email']; ?>">
            </div>
        </div>
        <div class="mb-3">
            <label for="bankName" class="form-label">Bank Name</label>
            <input type="text" class="form-control" id="bankName" aria-describedby="emailHelp" name="bankName">
        </div>
        <div class="mb-3">
            <label for="cardnum" class="form-label">Card Number </label>
            <input type="number" class="form-control" id="cardnum" name="cardnum">
         </div>
         <select class="form-select mb-3" aria-label="Default select example" name="course">
            <option selected>Select a Course</option>
            <option value="Java Programming">Java Programming</option>
            <option value="PHP Programming">PHP Programming</option>
            <option value="JavaScript for Beginners">JavaScript for Beginners</option>
            <option value="CSS Designing">CSS Designing</option>
            <option value="C Programming">C Programming</option>
            <option value="C++ Programming">C++ Programming</option>
            <option value="SQL Database">SQL Database</option>
            <option value="Python Programming">Python Programming</option>
        </select>
            <button type="submit" class="btn btn-success">Confirm</button>
    </form>
      </div>











<script src="js/bootstrap.js"></script>
</body>
</html>