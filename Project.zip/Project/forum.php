<?php
session_start();
$login = false;
$showLoginAlert = false;
$showLoginButton = true;
// Include database connection script
include 'dbconnect.php';

// Query to fetch records from forumentry table
$query = "SELECT * FROM forumentry f, users_all u WHERE f.id = u.id;";
$result = mysqli_query($conn, $query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum Entries</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <style>
        .card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body style="background-image: url(background1.1.png); background-size: cover;">
<nav class="navbar navbar-expand-lg" data-bs-theme="dark" style="background-color: #030303;">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
            <img src="elements/logo.png" alt="Logo" width="28" height="28" class="d-inline-block align-text-top">
            OLPA
          </a>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="courses.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="pricing.php">Membership</a>
              </li>
            </ul>
          </div>

          <?php if(isset($_SESSION['loggedin'])){ ?>

            <a href="profile.php"><button type="button" class="btn btn-outline-light">Your Profile</button></a>

          <?php }else{
          echo '

          <!-- LOGIN MODAL-->
          <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Login
          </button>
          
          <div class="modal" style="color: white;" tabindex="-1" id="exampleModal">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Enter your email and password</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="index.php">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="email" name="login_email" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="login_password">
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;">Login</button>
                    <div style="text-align: center; margin-top: 20px;">
                        <a href="">Forgot Password?</a>
                    </div>
                </form>
                </div>
                <hr style="margin-top: 0px;">
                <div>
                  <div class="form-text"  style="text-align: center; margin-top: 0; margin-bottom: 15px;">Do not have an account? <br><a href="signup.php  ">Sign Up</a> Here.</div>
                </div>
              </div>
            </div>
          </div>';
          }
          ?>
        </div>
      </nav>
      <?php
          if($showLoginAlert){
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Error!</strong> Your password or username is incorrect.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
          }
          if($login){
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> You are logged in.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
          }
          ?>
<div class="container" style="margin-top: 50px;">
    <h1 style="text-align: center;">Forum Entries</h1>
    <div class="row">
        <?php
        // Check if there are records
        if (mysqli_num_rows($result) > 0) {
            // Loop through each record
            while ($row = mysqli_fetch_assoc($result)) {
                ?>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Forum ID: <?php echo $row['forumid']; ?></h5>
                            <h6 class="card-subtitle mb-2 text-muted">Date/Time: <?php echo $row['date/time']; ?></h6>
                            <p class="card-text">Forum Subject: <?php echo $row['forumsub']; ?></p>
                            <p class="card-text">Content: <?php echo $row['content']; ?></p>
                            <p class="card-text">Email: <?php echo $row['email']; ?></p>
                            <!-- You can add Edit, Copy, and Delete buttons here -->
                            <!-- Example: -->
                            <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">Edit</a>
                            <a href="copy.php?id=<?php echo $row['id']; ?>" class="btn btn-secondary">Copy</a>
                            <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">Delete</a>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            // If no records found
            echo "<p>No forum entries found.</p>";
        }
        ?>
    </div>
</div>

<script src="js/bootstrap.js"></script>
</body>
</html>

<?php
// Close database connection
mysqli_close($conn);
?>
