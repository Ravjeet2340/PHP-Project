<?php
include 'dbconnect.php'; // Include database connection script

session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
    header("location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<style>
  .upload{
      width: 140px;
      position: relative;
      margin: auto;
      text-align: center;
      margin-bottom: 20px;
    }
    .upload img{
      border-radius: 50%;
      border: 8px solid #DCDCDC;
      width: 125px;
      height: 125px;
    }
    .upload .rightRound{
      position: absolute;
      bottom: 0;
      right: 0;
      background: #00B4FF;
      width: 32px;
      height: 32px;
      line-height: 33px;
      text-align: center;
      border-radius: 50%;
      overflow: hidden;
      cursor: pointer;
    }
    .upload .leftRound{
      position: absolute;
      bottom: 0;
      left: 0;
      background: red;
      width: 32px;
      height: 32px;
      line-height: 30px;
      text-align: center;
      border-radius: 50%;
      overflow: hidden;
      cursor: pointer;
    }
    .upload .fa{
      color: white;
    }
    .upload input{
      position: absolute;
      transform: scale(2);
      opacity: 0;
    }
    .upload input::-webkit-file-upload-button, .upload input[type=submit]{
      cursor: pointer;
    }
</style>
<body style="background-image: url(background1.1.png); background-size: cover;"> 
    
<nav class="navbar navbar-expand-lg" data-bs-theme="dark" style="background-color: #030303;">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
            <img src="elements/logo.png" alt="Logo" width="28" height="28" class="d-inline-block align-text-top">
            OLPA
          </a>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="courses.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="pricing.php">Membership</a>
              </li>
            </ul>
          </div>

          <?php if(isset($_SESSION['loggedin'])){ ?>
          <a href="logout.php"><button type="button" class="btn btn-outline-light" style="margin-left: 5px;">Logout</button></a>
          <?php }
          ?>
        </div>
      </nav>

    <div class="container" style="width: 50%; margin-top: 50px;">
        <div class="card" style="width: 100%;">
            <div class="card-body">
                <h5 class="card-title" style="font-size: 30px;">Your Profile</h5>
                <h6 class="card-subtitle mb-2 text-body-secondary">Update or remove details here.</h6><br>
                <div class="upload">
        <img src="img/<?php echo $_SESSION['imageName']; ?>" id = "image" width="125px" height="125px">
    </div>
    <hr>
                <p class="card-text" style="margin-bottom: 20px;">Username: <?php echo $_SESSION['username']['username']; ?>  <button style="display: flex; float: right; border-radius: 5px; background-color: white; border: solid black 1.5px; font-size: 14px;" type="button" >Update</button></p>
                <hr>
                <p class="card-text">Email: <?php echo $_SESSION['email'];?> <button style="display: flex; float: right; border-radius: 5px; background-color: white; border: solid black 1.5px; font-size: 14px;" type="button">Update</button></p>
                <hr>
                <h5 class="card-title" style="font-size: 24px;">Your Courses</h5>
                <?php
                $userID = $_SESSION['id'];
                $query = "SELECT courseName FROM coursesenrolled WHERE id = '$userID'";
                $result = mysqli_query($conn, $query);

                if ($result && mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<p class='card-text'>" . $row['courseName'] . "</p>";
                    }
                } else {
                    echo "<p class='card-text'>No courses enrolled.</p>";
                }
                ?>
                <hr>
                <h5 class="card-title" style="font-size: 24px;">Your Subscriptions</h5>
                <?php
                  $query2 = "SELECT name FROM subscriptions WHERE id = '$userID';";
                  $result2 = mysqli_query($conn, $query2);
                  if($result2 && mysqli_num_rows($result2) > 0){
                    while($row = mysqli_fetch_assoc($result2)){
                      echo "<p class='card-text'>" . $row['name'] . "</p>";
                    } 
                  } else {
                      echo "<p class='card-text'>No subscriptions.</p>";  
                    }
                ?>
            </div>
        </div>
    </div>

    <script src="js/bootstrap.js"></script>
</body>
</html>
