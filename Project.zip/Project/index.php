<?php
session_start();
$login = false;
$showLoginAlert = false;
$showLoginButton = true;


if($_SERVER['REQUEST_METHOD']=="POST"){
  include 'dbconnect.php';
  $login_email = $_POST["login_email"];
  $login_password = $_POST["login_password"];

  $query2 = "SELECT * FROM users_all WHERE email = '$login_email' AND password = '$login_password';";
  $query3 = "SELECT username FROM users_all WHERE email = '$login_email';";
  $query4 = "SELECT img FROM `users_all` WHERE email = '$login_email';"; // Query to fetch image name
  
  $result1 = mysqli_query($conn, $query2);
  $result2 = mysqli_query($conn, $query3);
  $result3 = mysqli_query($conn, $query4);

  
  $username = mysqli_fetch_assoc($result2);
  $imageName_row = mysqli_fetch_assoc($result3); // Fetch the image name row

  if($imageName_row) {
    $imageName = $imageName_row['img'];
  }

  $usernum = mysqli_num_rows($result1);


  if($usernum == 1){
    $login = true;
    $_SESSION['loggedin'] = true;
    $_SESSION['email'] = $login_email;
    $_SESSION['username'] = $username;
    $_SESSION['imageName'] = $imageName; // Store the image name in the session
    header("location: index.php");
  }else{
    $showLoginAlert = true;
  }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="css\bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
  $(document).ready(function(){
  $("#flip").click(function(){
    $("#panel").slideToggle("slow");
  });
});
  </script>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        .container{
            position: absolute;
            top: 36%;
            left: 60px;
        }
        body{
            background: url(background.png);
            background-repeat: no-repeat;
            background-size: cover;
            display: flex;
            flex-direction: column;
            min-height: 105vh;
        }
        .heading1{
            color: black;
            font-size: 58px;
            font-weight: 600;
            margin-bottom: -4px;
        }
        .heading2{
            color: black;
            font-size: 30px;
            font-weight: 300;
            margin-bottom: 20px;
        }
        .start{
            padding: 10px;
            font-size: 20px;
            border: solid black 2px;
            border-radius: 5px;
            color: black;
            background-color: transparent;
            transition: 0.25s;
        }
        .start:hover{
            background-color: black;
            color: white;
        }

        footer{
            margin-top: auto; /* Push the footer to the bottom */
            width: 100%;
            background-color: #030303;
            color: white;
            text-align: center;
            padding: 5px 0 5px 0;
            
        }

        @media only screen and (min-width: 600px) {
            .brand-name,
            ul {
                display: inline-block;
                vertical-align: middle;
            }
            .item {
                display: inline-block;
                margin-top: 0;
            }   
        }
    </style>

</head>
<body>

    <nav class="navbar navbar-expand-lg" data-bs-theme="dark" style="background-color: #030303;">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
            <img src="elements/logo.png" alt="Logo" width="28" height="28" class="d-inline-block align-text-top">
            OLPA
          </a>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="courses.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="pricing.php">Membership</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="forum.php">Forum</a>
              </li>
            </ul>
          </div>

          <?php if(isset($_SESSION['loggedin'])){ ?>

            <a href="profile.php"><button type="button" class="btn btn-outline-light">Your Profile</button></a>

          <?php }else{
          echo '

          <!-- LOGIN MODAL-->
          <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Login
          </button>
          
          <div class="modal" style="color: white;" tabindex="-1" id="exampleModal">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Enter your email and password</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="index.php">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="email" name="login_email" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="login_password">
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;">Login</button>
                    <div style="text-align: center; margin-top: 20px;">
                        <a href="">Forgot Password?</a>
                    </div>
                </form>
                </div>
                <hr style="margin-top: 0px;">
                <div>
                  <div class="form-text"  style="text-align: center; margin-top: 0; margin-bottom: 15px;">Do not have an account? <br><a href="signup.php  ">Sign Up</a> Here.</div>
                </div>
              </div>
            </div>
          </div>';
          }
          ?>
        </div>
      </nav>
      <?php
          if($showLoginAlert){
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Error!</strong> Your password or username is incorrect.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
          }
          if($login){
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> You are logged in.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
          }
          ?>

    <div class="container">
        <h1 class="heading1" data-value="3">OLPA</h1>
        <h3 class="heading2" data-value="3">An Online Learning Platform</h3>
        <a href="courses.php"><button class="start" data-value="3">Get Started</button></a><br>
    </div>
    <?php if(isset($_SESSION['loggedin'])){ ?>
    <div>
    <div class="card" style="width: 20rem; margin-left: auto; margin-top: 80px; margin-right: 100px; color: white; background-color: #00000000;">
      <div id="carouselExample" class="carousel slide">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="elements/java.png" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="elements/js.png" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="elements/SQL.png" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="elements/css.png" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="elements/python.png" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="elements/c.png" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="elements/c++.png" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="elements/react.png" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="elements/ml.png" class="d-block w-100" alt="...">
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
<div class="card-body">
<h5 class="card-title" style="font-size: 24px;">Choose your course now.</h5>
<p class="card-text">Welcome to our online learning platform, where knowledge meets convenience and learning knows no bounds.</p>
<a href="courses.php" class="btn btn-primary">Learn More</a>
</div>
</div>
</div>
<?php } ?>
    <?php
    // Include the database connection file
    include 'dbconnect.php';

    // Check if the 'email' key is set in the session
    if (isset($_SESSION['email'])) {
        $email = $_SESSION['email'];

        // Prepare the SQL statement using a prepared statement
        $query = "SELECT id FROM users_all WHERE email = ?";

        // Prepare the statement
        $stmt = mysqli_prepare($conn, $query);

        if ($stmt) {
            // Bind parameters to the prepared statement
            mysqli_stmt_bind_param($stmt, "s", $email);

            // Execute the statement
            mysqli_stmt_execute($stmt);

            // Bind the result variables
            mysqli_stmt_bind_result($stmt, $id);

            // Fetch the result
            mysqli_stmt_fetch($stmt);

            // Check if a row was found
            if ($id) {
                // Store the id in the session
                $_SESSION['id'] = $id;
            }
        }

        // Close the statement
        mysqli_stmt_close($stmt);
    } else {
        $email = ""; // Set a default value or handle the absence of the key as needed
    }

    // Close the database connection
    mysqli_close($conn);
    ?>

    <footer>
    <div id="flip">
        <p>&copy; 2024 OLPA. All rights reserved.</p>
    </div>
    <div id="panel" style="display: none;">
    <hr>
    <div style="padding: 10px;">
        <div class="row" style="margin-right: 0px;">
            <div class="col-md-6">
                <h4>Contact Us</h4>
                <p>Email: info@example.com</p>
                <p>Phone: +1234567890</p>
                <p>Address: 123 Main Street, City, Country</p>
            </div>
            <div class="col-md-6">
                <h4>Follow Us</h4>
                <ul class="list-inline">
                    <li class="list-inline-item"><a href="#"><i class="fab fa-facebook"></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fab fa-instagram"></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
        </div>
        
    </div>
    </div>
    </footer>


    <script src="js\bootstrap.js"></script>

</body>
</html>
