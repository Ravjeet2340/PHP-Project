<?php
session_start();
// Assuming you already have a database connection established
include 'dbconnect.php';

// Assuming $email and $password contain the user's input from a form
$email = $_SESSION['email'];


// Prepare the SQL statement using a prepared statement
$query = "SELECT id FROM users_all WHERE email = ?";

// Prepare the statement
$stmt = mysqli_prepare($conn, $query);

if ($stmt) {
    // Bind parameters to the prepared statement
    mysqli_stmt_bind_param($stmt, "s", $email);

    // Execute the statement
    mysqli_stmt_execute($stmt);

    // Bind the result variables
    mysqli_stmt_bind_result($stmt, $id);

    // Fetch the result
    mysqli_stmt_fetch($stmt);

    // Check if a row was found
    if ($id) {
        // Output or use the id as needed
        $_SESSION['id'] = $id;
    } else {
        // No matching user found
        echo "User not found.";
    }

    // Close the statement
    mysqli_stmt_close($stmt);
} else {
    // Query execution failed
    echo "Error: " . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);
?>
