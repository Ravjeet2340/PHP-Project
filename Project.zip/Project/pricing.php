<?php
session_start();
$login = false;
$showLoginAlert = false;
$showLoginButton = true;


if($_SERVER['REQUEST_METHOD']=="POST"){
  include 'dbconnect.php';
  $login_email = $_POST["login_email"];
  $login_password = $_POST["login_password"];

  $query2 = "SELECT * FROM users_all WHERE email = '$login_email' AND password = '$login_password';";
  $query3 = "SELECT username FROM users_all WHERE email = '$login_email';";
  
  $result1 = mysqli_query($conn, $query2);
  $result2 = mysqli_query($conn, $query3);

  
  $username = mysqli_fetch_assoc($result2);

  $usernum = mysqli_num_rows($result1);


  if($usernum == 1){
    $login = true;
    $_SESSION['loggedin'] = true;
    $_SESSION['email'] = $login_email;
    $_SESSION['username'] = $username;
    header("location: index.php");
  }else{
    $showLoginAlert = true;
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>subscriptions</title>
    <link rel="stylesheet" href="css\bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
  $(document).ready(function(){
  $("#flip").click(function(){
    $("#panel").slideToggle("slow");
  });
});
</script>
</head>
<body style="background-image: url(background1.1.png); background-size: contain;">
    
<nav class="navbar navbar-expand-lg" data-bs-theme="dark" style="background-color: #030303;">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
            <img src="elements/logo.png" alt="Logo" width="28" height="28" class="d-inline-block align-text-top">
            OLPA
          </a>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="courses.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="pricing.php">Membership</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="forum.php">Forum</a>
              </li>
            </ul>
          </div>

          <?php if(isset($_SESSION['loggedin'])){ ?>

            <a href="profile.php"><button type="button" class="btn btn-outline-light">Your Profile</button></a>

          <?php }else{
          echo '

          <!-- LOGIN MODAL-->
          <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Login
          </button>
          
          <div class="modal" style="color: white;" tabindex="-1" id="exampleModal">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Enter your email and password</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="index.php">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="email" name="login_email" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="login_password">
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;">Login</button>
                    <div style="text-align: center; margin-top: 20px;">
                        <a href="">Forgot Password?</a>
                    </div>
                </form>
                </div>
                <hr style="margin-top: 0px;">
                <div>
                  <div class="form-text"  style="text-align: center; margin-top: 0; margin-bottom: 15px;">Do not have an account? <br><a href="signup.php  ">Sign Up</a> Here.</div>
                </div>
              </div>
            </div>
          </div>';
          }
          ?>
        </div>
      </nav>

        <div class="container mt-5 mb-5" style="width: 70%;">

          <h1>Choose plan that suits you the best</h1><br>
          
          <div class="row row-cols-1 row-cols-md-3 g-4">
            <div class="col">
              <div class="card">
                <img src="elements/casuallearner.png" class="card-img-top">
                <div class="card-body">
                  <p class="card-text">
                    A casual learner plan offers flexibility and variety, allowing individuals to explore diverse topics at their own pace. It promotes curiosity and self-directed learning through accessible resources and minimal commitment.</p><br>
                    <a href="casualplan.php"><button type="button" class="btn btn-outline-primary">Buy Now</button></a>
                  </div>
              </div>
            </div>
            <div class="col">
              <div class="card">
                <img src="elements/intermediatelearner.png" class="card-img-top">
                <div class="card-body">
                  <p class="card-text">
                    An intermediate learner plan provides structured guidance and resources to individuals seeking to deepen their knowledge and skills in specific areas. It combines curated materials with interactive exercises to facilitate steady progress.</p>
                    <a href="casualplan.php"><button type="button" class="btn btn-outline-primary">Buy Now</button></a>
                  </div>
              </div>
            </div>
            <div class="col">
              <div class="card">
                <img src="elements/advancedlearner.png" class="card-img-top">
                <div class="card-body">
                  <p class="card-text">
                    An advanced learner plan offers specialized and advanced content tailored to individuals aiming for mastery in their chosen fields. It includes advanced materials, challenging projects, and opportunities for collaboration and mentorship.</p>
                    <a href="casualplan.php"><button type="button" class="btn btn-outline-primary">Buy Now</button></a>
                  </div>
              </div>
            </div>
            </div>
          </div>
        </div>
        <footer style="margin-top: 100px; text-align: center; background-color: #030303; margin-bottom: -20px; color: white;">
    <div id="flip">
        <p>&copy; 2024 OLPA. All rights reserved.</p>
    </div>
    <div id="panel" style="display: none;">
    <hr>
    <div style="padding: 10px;">
        <div class="row" style="margin-right: 0px;">
            <div class="col-md-6">
                <h4>Contact Us</h4>
                <p>Email: info@example.com</p>
                <p>Phone: +1234567890</p>
                <p>Address: 123 Main Street, City, Country</p>
            </div>
            <div class="col-md-6">
                <h4>Follow Us</h4>
                <ul class="list-inline">
                    <li class="list-inline-item"><a href="#"><i class="fab fa-facebook"></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fab fa-instagram"></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fab fa-linkedin"></i></a></li>
                </ul>
            </div>
        </div>
        
    </div>
    </div>
    </footer>


      <script src="js\bootstrap.js"></script>
    </body>
</html>