<?php
    $showAlert = false;
    $showError = false;
    $showExistsError = false;
if($_SERVER['REQUEST_METHOD'] == "POST"){
    include 'dbconnect.php';
    $signup_username = $_POST["signup_username"];
    $signup_email = $_POST["signup_email"];
    $signup_password = $_POST["signup_password"];
    $signup_cpassword = $_POST["signup_confirmpassword"]; 


    if (isset($_FILES["fileImg"]) && $_FILES["fileImg"]["error"] === 0) {
      $src = $_FILES["fileImg"]["tmp_name"];
      $imageName = uniqid() . $_FILES["fileImg"]["name"];
      $target = "img/" . $imageName;
      move_uploaded_file($src, $target);
  } else {
      $imageName = ""; // Set a default value for imageName if fileImg is not uploaded or has an error
  }




    $username_exists = false;
    $email_exists = false;

    $username_existsSql = "SELECT * FROM `users_all` WHERE username = '$signup_username';";
    $username_existsResult = mysqli_query($conn, $username_existsSql);
    $numUsernameExists = mysqli_num_rows($username_existsResult);


    $email_existsSql = "SELECT * FROM `users_all` WHERE email = '$signup_email';";
    $email_existsResult = mysqli_query($conn, $email_existsSql);
    $numEmailExists = mysqli_num_rows($email_existsResult);



    if($numUsernameExists!=0 || $numEmailExists!=0){
      $username_exists = true;
      $email_exists = true;
      $showExistsError = true;

    }
    else{
      $username_exists = false;
      $email_exists = false;

        if(($signup_password == $signup_cpassword) && ($username_exists==false) && ($email_exists==false)){
            $query1 = "INSERT INTO `users_all` (`img`, `username`, `email`, `password`, `Date/Time`) VALUES ('$imageName', '$signup_username', '$signup_email', '$signup_password', current_timestamp());";
            $result = mysqli_query($conn, $query1);
            if($result){
                $showAlert = true;
            }
        }
        else{
            $showError = "Passwords do not match. Please enter the same passwords in the given fields.";
        }
  }
}








?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="css\bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
  .upload{
      width: 140px;
      position: relative;
      margin: auto;
      text-align: center;
      margin-bottom: 20px;
    }
    .upload img{
      border-radius: 50%;
      border: 8px solid #DCDCDC;
      width: 125px;
      height: 125px;
    }
    .upload .rightRound{
      position: absolute;
      bottom: 0;
      right: 0;
      background: #00B4FF;
      width: 32px;
      height: 32px;
      line-height: 33px;
      text-align: center;
      border-radius: 50%;
      overflow: hidden;
      cursor: pointer;
    }
    .upload .leftRound{
      position: absolute;
      bottom: 0;
      left: 0;
      background: red;
      width: 32px;
      height: 32px;
      line-height: 30px;
      text-align: center;
      border-radius: 50%;
      overflow: hidden;
      cursor: pointer;
    }
    .upload .fa{
      color: white;
    }
    .upload input{
      position: absolute;
      transform: scale(2);
      opacity: 0;
    }
    .upload input::-webkit-file-upload-button, .upload input[type=submit]{
      cursor: pointer;
    }
</style>
<body style="background-image: url(background1.1.png); background-size: cover;"> 

    <nav class="navbar navbar-expand-lg" data-bs-theme="dark" style="background-color: #030303;">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
            <img src="elements/logo.png" alt="Logo" width="28" height="28" class="d-inline-block align-text-top">
            OLPA
          </a>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="courses.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="pricing.php">Membership</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    
</div>  


<?php
if($showAlert){
echo '
<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success!</strong> Your account has been created. You can now login to your account.
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
}
if($showError){
    echo '
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <strong>Error!</strong> '. $showError .'
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
    } 
    if($showExistsError){
      echo '
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> Username or Email already exists. Please enter different credentials.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
      } 
?>





<div class="container" style="width: 50%; margin-top: 30px;">
    <h1 style="margin-top: 30px; margin-bottom: 30px;">
        Register an account
    </h1>

    
    
    
    <form method="POST" action="signup.php" enctype="multipart/form-data">
    <div class="upload">
        <img src="img/noprofil.jpg" id = "image">

        <div class="rightRound" id = "upload">
        <input type="file" name="fileImg" id="fileImg" accept=".jpg, .jpeg, .png">
          <i class = "fa fa-camera"></i>
        </div>

        <div class="leftRound" id = "cancel" style = "display: none;">
          <i class = "fa fa-times"></i>
        </div>

      </div>
        <div class="input-group mb-3">
        <span class="input-group-text">@</span>
        <div class="form-floating">
        <input type="text" class="form-control" id="signup_username" placeholder="Username" name="signup_username">
        <label for="signup_username">Username</label>
        </div>
        </div>
        <div class="form-floating mb-3">
            <input type="email" class="form-control" id="signup_email" placeholder="name@example.com" name="signup_email">
            <label for="signup_email" >Email address</label>
          </div>
          <div class="form-floating">
            <input type="password" class="form-control" id="signup_password" placeholder="Password" name="signup_password">
            <label for="signup_passowrd" >Password</label>
            <div id="passwordHelpBlock" class="form-text">
                Your password must be 8-20 characters long, contain letters and numbers, and must not contain spaces, special characters, or emoji.
              </div>
          </div>
          <div class="form-floating" style="margin-top: 20px;">
            <input type="password" class="form-control" id="signup_confirmPassword" placeholder="Password" name="signup_confirmpassword">
            <label for="signup_confirmPassword" >Confirm Password</label>
            <div id="passwordHelpBlock" class="form-text">
                Make sure the passwords are same.
    </div>  
            <br>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
</div>
    

    <script src="js\bootstrap.js"></script>
    <script type="text/javascript">
      document.getElementById("fileImg").onchange = function(){
        document.getElementById("image").src = URL.createObjectURL(fileImg.files[0]); // Preview new image

        document.getElementById("cancel").style.display = "block";

        document.getElementById("upload").style.display = "none";
      }

      var userImage = document.getElementById('image').src;
      document.getElementById("cancel").onclick = function(){
        document.getElementById("image").src = userImage; // Back to previous image

        document.getElementById("cancel").style.display = "none";

        document.getElementById("upload").style.display = "block";
      }
    </script>
</body>
</html>