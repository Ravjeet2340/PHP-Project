<?php
$username = "root";
$password = "";
$servername = "localhost:3308";
$dbname = "user2003";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if(!$conn){
    die("Error!" . mysqli_connect_error());
}
?>