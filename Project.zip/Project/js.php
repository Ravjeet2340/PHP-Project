<?php
session_start();
$login = false;
$showLoginAlert = false;
$showLoginButton = true;


if($_SERVER['REQUEST_METHOD']=="POST"){
  include 'dbconnect.php';
  $login_email = $_POST["login_email"];
  $login_password = $_POST["login_password"];

  $query2 = "SELECT * FROM users_all WHERE email = '$login_email' AND password = '$login_password';";
  $query3 = "SELECT username FROM users_all WHERE email = '$login_email';";
  
  $result1 = mysqli_query($conn, $query2);
  $result2 = mysqli_query($conn, $query3);

  
  $username = mysqli_fetch_assoc($result2);

  $usernum = mysqli_num_rows($result1);


  if($usernum == 1){
    $login = true;
    $_SESSION['loggedin'] = true;
    $_SESSION['email'] = $login_email;
    $_SESSION['username'] = $username;
    header("location: index.php");
  }else{
    $showLoginAlert = true;
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<style>
</style>
<body>
<nav class="navbar navbar-expand-lg" data-bs-theme="dark" style="background-color: #030303;">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
            <img src="elements/logo.png" alt="Logo" width="28" height="28" class="d-inline-block align-text-top">
            OLPA
          </a>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="courses.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="pricing.php">Membership</a>
              </li>
            </ul>
          </div>

          <?php if(isset($_SESSION['loggedin'])){ ?>

            <a href="profile.php"><button type="button" class="btn btn-outline-light">Your Profile</button></a>

          <?php }else{
          echo '

          <!-- LOGIN MODAL-->
          <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Login
          </button>
          
          <div class="modal" style="color: white;" tabindex="-1" id="exampleModal">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Enter your email and password</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="index.php">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="email" name="login_email" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="login_password">
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;">Login</button>
                    <div style="text-align: center; margin-top: 20px;">
                        <a href="">Forgot Password?</a>
                    </div>
                </form>
                </div>
                <hr style="margin-top: 0px;">
                <div>
                  <div class="form-text"  style="text-align: center; margin-top: 0; margin-bottom: 15px;">Do not have an account? <br><a href="signup.php  ">Sign Up</a> Here.</div>
                </div>
              </div>
            </div>
          </div>';
          }
          ?>
        </div>
      </nav>



  <div class="container mt-5">

    <div style="display: flex;">
      <div style="width: 100%;">

      <div>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item"><a href="courses.php">Courses</a></li>
            <li class="breadcrumb-item active" aria-current="page">Java Script Programming</li>
          </ol>
        </nav>
        <h1 class="mt-5 mb-3" style="font-size: 32px;">Java Script Programming for Beginners</h1>
        <p style="font-weight: 400;">JavaScript is a versatile scripting language used for web development. With its ability to create dynamic and interactive web pages, JavaScript is essential for enhancing user experience and adding functionality to websites.</p>
        <img src="elements/4.4star.png" alt="">
      </div>


    <div style="margin-bottom: 60px; margin-top: 60px;">
        <img src="elements/java__p1.png" alt="" height="220px" width="400px" style="border: solid #030303 1px;">
    </div>

    <div style="background-color: grey; width: 90%; height: 2px; border-radius: 2px;"></div>
    

      <div style="margin-top: 25px; margin-bottom: 25px;">
        <img src="elements/java__p2.png" alt="" width="700px" height="170px">
      </div>
    

    <div style="display: flex; margin-top: 50px;">

      <div style="width: 100%; margin-right: 10px;">
        <h4>Try a simple coding Excercise</h4>
        <p>Write a JavaScript function to find the factorial of a given number. The factorial of a non-negative integer n, denoted by n!, is the product of all positive integers less than or equal to n.</p>

        <button type="button" class="btn btn-outline-primary">Get Started</button>
      </div>

      <div>
        <img src="elements/java__p3.png" alt="" height="150px" width="300px" style="border-radius: 5px; margin-right: 10px; margin-bottom: 100px;">
      </div>
    </div>

  </div>

  <div>
    <div class="card" style="width: 100%;">
      <div>
        <video src="elements/java__back.mp4"  class="object-fit-contain" height="300px" width="400px" autoplay></video>
      </div>
      <div class="card-body">
        <h5 class="card-title">Subscribe to a plan</h5>
        <p class="card-text">Get this course, plus 50+ of our top-rated courses, with Personal Plan. <a href="pricing.html"> Learn More</a></p>
        <a href="pricing.html" class="btn btn-primary" style="width: 100%;">Start Subscription</a>
        <p class="card-text" style="text-align: center; margin-top: 20px;"><small class="text-body-secondary">Starting at $29 per year <br>
          Cancel anytime</small></p>

        <div style="height: 1px; background-color: #030303; margin-top: 30px; margin-bottom: 30px;"></div>

        <h5 class="card-title">Or buy this course for:</h5>
        <h5 class="card-title" style="font-weight: 600; font-size: 28px; margin-top: 20px; margin-bottom: 20px;">$50.00</h5>

        <a href="pricing.html" class="btn btn-primary" style="width: 100%;">Add to Cart</a>

        <p class="card-text" style="text-align: center; margin-top: 20px;"><small class="text-body-secondary">30-Days Money Back Guarantee<br>
          Full Time Access</small></p>

          <div style="height: 1px; background-color: #030303; margin-top: 30px; margin-bottom: 30px;"></div>

          <p class="card-text">Apply a Coupon Here.</p>

         <input type="text" style="height: 30px; width: 100%; text-align: center; margin-top: 10px;
         margin-bottom: 10px;" placeholder="ADAV-1465-FDSA" >
         <button type="button" class="btn btn-outline-primary" style="width: 100%;">Apply</button>
        
      </div>
    </div>
  </div>

  </div>

  </div>

            



      <script src="js/bootstrap.js"></script>
</body>
</html>