<?php
session_start();
$login = false;
$showLoginAlert = false;
$showLoginButton = true;


if($_SERVER['REQUEST_METHOD']=="POST"){
  include 'dbconnect.php';
  $login_email = $_POST["login_email"];
  $login_password = $_POST["login_password"];

  $query2 = "SELECT * FROM users_all WHERE email = '$login_email' AND password = '$login_password';";
  $query3 = "SELECT username FROM users_all WHERE email = '$login_email';";
  $query4 = "SELECT img FROM `users_all` WHERE email = '$login_email';"; // Query to fetch image name
  
  $result1 = mysqli_query($conn, $query2);
  $result2 = mysqli_query($conn, $query3);
  $result3 = mysqli_query($conn, $query4);

  
  $username = mysqli_fetch_assoc($result2);
  $imageName_row = mysqli_fetch_assoc($result3); // Fetch the image name row

  if($imageName_row) {
    $imageName = $imageName_row['img'];
  }

  $usernum = mysqli_num_rows($result1);


  if($usernum == 1){
    $login = true;
    $_SESSION['loggedin'] = true;
    $_SESSION['email'] = $login_email;
    $_SESSION['username'] = $username;
    $_SESSION['imageName'] = $imageName; // Store the image name in the session
    header("location: index.php");
  }else{
    $showLoginAlert = true;
  }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="css\bootstrap.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body style="background-image: url(background1.1.png); background-size: cover;">
<nav class="navbar navbar-expand-lg" data-bs-theme="dark" style="background-color: #030303;">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php">
            <img src="elements/logo.png" alt="Logo" width="28" height="28" class="d-inline-block align-text-top">
            OLPA
          </a>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="courses.php">Courses</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="pricing.php">Membership</a>
              </li>
            </ul>
          </div>
          </div>
      </nav>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Sorry!</strong> You have to login before continuing.
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>

<div class="container">
<h2 style="text-align: center; margin-top: 50px;">Please login before continuing.</h2>
    <div class="row justify-content-center mt-5">
      <div class="col-md-6">
        <div class="card">
          <div class="card-header">
            <h4>Login</h4>
          </div>
          <div class="card-body">
            <form action="loginpage.php" method="POST">
              <div class="form-group">
                <label for="username">Email</label>
                <input type="text" class="form-control" id="username" name="login_email" required>
              </div>
              <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="login_password" required>
              </div>
              <button type="submit" class="btn btn-primary">Login</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php
    // Include the database connection file
    include 'dbconnect.php';

    // Check if the 'email' key is set in the session
    if (isset($_SESSION['email'])) {
        $email = $_SESSION['email'];

        // Prepare the SQL statement using a prepared statement
        $query = "SELECT id FROM users_all WHERE email = ?";

        // Prepare the statement
        $stmt = mysqli_prepare($conn, $query);

        if ($stmt) {
            // Bind parameters to the prepared statement
            mysqli_stmt_bind_param($stmt, "s", $email);

            // Execute the statement
            mysqli_stmt_execute($stmt);

            // Bind the result variables
            mysqli_stmt_bind_result($stmt, $id);

            // Fetch the result
            mysqli_stmt_fetch($stmt);

            // Check if a row was found
            if ($id) {
                // Store the id in the session
                $_SESSION['id'] = $id;
            }
        }

        // Close the statement
        mysqli_stmt_close($stmt);
    } else {
        $email = ""; // Set a default value or handle the absence of the key as needed
    }

    // Close the database connection
    mysqli_close($conn);
    ?>
  
  <script src="js\bootstrap.js"></script>
</body>
</html>